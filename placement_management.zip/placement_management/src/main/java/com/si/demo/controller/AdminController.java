package com.si.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;


import com.si.demo.entity.Admin;
import com.si.demo.service.AdminService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@PostMapping("/admins")
	public Admin saveAdmin(@RequestBody Admin admin) {
		
		
		return adminService.saveAdmin(admin);
	}
	
	@GetMapping("/admins")
    public List<Admin> fetchAdminList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return adminService.fetchAdminList();
    }
	
	@GetMapping("/admins/{id}")
    public Admin fetchAdminById(@PathVariable("id") Long id)
            {
        return adminService.fetchAdminById(id);
    }
	
	 @DeleteMapping("/admins/{id}")
	    public String deleteAdminById(@PathVariable("id") Long id) {
	        adminService.deleteAdminById(id);
	        return "Admin deleted Successfully!!";
	        
	 }
	 
	 @PutMapping("/admins/{id}")
	    public Admin updateAdmin(@PathVariable("id") Long id,
	                                       @RequestBody Admin admin) {
	        return adminService.updateAdmin(id,admin);
	    }
	 
}
